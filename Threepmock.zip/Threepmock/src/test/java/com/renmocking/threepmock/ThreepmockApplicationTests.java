package com.renmocking.threepmock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreepmockApplicationTests {

    @Test
    void contextLoads() {
    }

}

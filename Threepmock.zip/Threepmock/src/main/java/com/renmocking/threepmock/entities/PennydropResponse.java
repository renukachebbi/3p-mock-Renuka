package com.renmocking.threepmock.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

public class PennydropResponse {
    private String status;

    private String txnId;

    public PennydropResponse() {
        this.status = "PENDING";
        this.txnId = "txnid1234";
    }


}

package com.renmocking.threepmock.controller;

import com.renmocking.threepmock.entities.Course;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.*;
import com.renmocking.threepmock.entities.PanResponse;
import com.renmocking.threepmock.entities.SubmitPanRequest;
import com.renmocking.threepmock.entities.PennydropResponse;
import com.renmocking.threepmock.entities.SubmitPennydropRequest;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@RestController
//@RequestMapping("/identify/composite/v1/extractAndVerify")
public class Mycontroller {
    List<Course> list = new ArrayList<>();



    @GetMapping("/home")
    public String home(){
        return "this is home page";
    }

    @GetMapping("/courses")
    public List<Course>getCourses()
    {
        list.add(new Course(11,"cr1","cr1 descrip"));
        list.add(new Course(11,"cr2","cr2 descrip"));

//        list.addAll().add(11, "crs 1", "on course 1"));
//        list.add(new Course(12,"crs 2","on course 2"));
//        list.add(new Course(13,"crs 3","on course 3"));
//
//        return list;
        return list;
    }

    @GetMapping("/courses/{courseId}")
    public Course getCourse(@PathVariable Long courseId)
    {
        Course c=null;
        for(Course course:list) {
            if (course.getId() == courseId) {
                c=course;
                break;
            }
        }
        return c;
    }

    @PostMapping("/courses")
    public Course addCourse(@RequestBody Course course)
    {
        list.add(course);
        return course;
    }
//    //for b2c pan and pennydrop post apis
//    @PostMapping("/identify/composite/v1/extractAndVerify/pan")
//    public Course addCourse(@RequestBody Course course)
//    {
//        list.add(course);
//        return course;
//    }

    @PostMapping("/identify/composite/v1/extractAndVerify/pan")
    public ResponseEntity<PanResponse> submitPan(
            @RequestHeader(value = "X-Api-Key") String apiKey,
            @Valid @ModelAttribute SubmitPanRequest submitPanRequest) {
//        log.info("Pan request : {}", submitPanRequest);
//        Event event = new Event(submitPanRequest.getUniqueId(), DocumentType.PAN.getName(),
//                Status.COMPLETED.getName(), 5);
//        kafkaProducer.publish(event);

        return ResponseEntity.ok(new PanResponse(submitPanRequest.getUniqueId()));
    }

    @PostMapping("/payout/composite/v1/pennydrop")
   public ResponseEntity<Object> submitPennydrop(
            @RequestHeader(value = "X-Api-Key") String apiKey,
            @RequestHeader(value = "X-Provider-Id") String providerId,
            @Valid @RequestBody SubmitPennydropRequest submitPanRequest
          ) {

//        log.info("submitPennydrop : {}", SubmitPennydropRequest);
//        Event event = new Event(submitPanRequest.getUniqueId(), DocumentType.PAN.getName(),
//                Status.COMPLETED.getName(), 5);
//        kafkaProducer.publish(event);

        return ResponseEntity.ok(new PennydropResponse());
    }

}

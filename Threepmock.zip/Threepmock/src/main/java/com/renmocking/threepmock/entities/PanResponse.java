package com.renmocking.threepmock.entities;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
//package com.yubi.fin.b2c.threep.domain;

@Data
@NoArgsConstructor
public class PanResponse {
    private String uniqueId;

    private Result result;

    public PanResponse(String uniqueId) {
        this.uniqueId = uniqueId;
        this.result = new Result();
    }

    @Data
    public static class Result {
        private int age = 23;

        @JsonProperty("date_of_birth")
        private String dateOfBirth = "22/09/1998";

        @JsonProperty("date_of_issue")
        private String dateOfIssue = "22/09/2021";

        @JsonProperty("fathers_name")
        private String fathersName = "John Doe";

        @JsonProperty("id_number")
        private String idNumber = "DPEAO8372D";

        @JsonProperty("is_scanned")
        private boolean isScanned = true;

        private boolean minor = false;

        @JsonProperty("name_on_card")
        private String nameOfCard = "Jane Doe";

        @JsonProperty("pan_type")
        private String panType;
    }
}



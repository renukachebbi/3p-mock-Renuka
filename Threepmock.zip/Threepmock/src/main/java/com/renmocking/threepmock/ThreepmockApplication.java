package com.renmocking.threepmock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreepmockApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThreepmockApplication.class, args);
    }

}

package com.renmocking.threepmock.entities;

import lombok.Data;

@Data
public class SubmitPennydropRequest {
    private String address1;
    private String bankAccount;

    private String city;
    private String email;
    private String ifsc;

    private String name;
    private String phone;
    private String pincode;

    private String sourceAccountNumber;

    private String state;
    private String topic;
    private String uniqueNum;

}

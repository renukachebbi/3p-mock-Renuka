package com.renmocking.threepmock.entities;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;


@Data
public class SubmitPanRequest {
    private String uniqueId;

    private String id;

    @NotBlank (message = "topic should not be blank")
    private String topic;

    private MultipartFile front;
}



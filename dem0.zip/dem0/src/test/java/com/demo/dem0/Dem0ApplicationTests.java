package com.demo.dem0;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dem0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
